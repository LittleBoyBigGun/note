# 总览

**nextEvent**(`event`, `options?`): `Promise`<`android.view.accessibility.AccessibilityEvent`>


# 参数
| 名称    | 类型             | 默认值 | 描述 |
| ------- | ---------------- | ------ | ---- |
| event   | string           | tbd    | tbd  |
| options | NextEventOptions | tbd    | tbd  | 

# 返回值

`Promise`<`android.view.accessibility.AccessibilityEvent`>

---
2023-02-15