# 总览

**performGestures**(`gestures`): `Promise`<`boolean`>

同时模拟多个手势。

# 参数

| 名称     | 类型                | 默认值 | 描述     |
| -------- | ------------------- | ------ | -------- |
| gestures | StrokeDescription[] | tbd    | 手势数组 | 

# 返回值

`Promise`<`boolean`>

---
2023-02-15