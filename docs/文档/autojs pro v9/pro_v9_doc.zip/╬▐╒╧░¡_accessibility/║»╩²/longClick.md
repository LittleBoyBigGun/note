# 总览

**longClick**(`x`, `y`): `Promise`<`boolean`>

长按屏幕指定位置。


# 参数
| 名称 | 类型   | 默认值 | 描述  |
| ---- | ------ | ------ | ----- |
| x    | number | tbd    | X坐标 |
| y    | number | tbd    | Y坐标 | 

# 返回值

`Promise`<`boolean`

---
2023-02-15