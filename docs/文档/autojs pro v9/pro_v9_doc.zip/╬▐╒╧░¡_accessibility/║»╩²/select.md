# 总览

**select**(`query?`): [`UiSelector`](https://web.archive.org/web/20221207132148/https://pro.autojs.org/docs/zh/v9/generated/classes/ui_selector.UiSelector.html)

UI选择。

# 参数

| 名称   | 类型          | 默认值 | 描述     |
| ------ | ------------- | ------ | -------- |
| query? | SelectorQuery | tbd    | 筛选条件 | 


# 返回值

`UiSelector`

Ui选择器

---
2023-02-15