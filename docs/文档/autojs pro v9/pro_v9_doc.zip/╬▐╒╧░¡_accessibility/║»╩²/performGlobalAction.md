# 总览

**performGlobalAction**(`action`): `boolean`

模拟全局按键

# 参数
| 名称   | 类型                       | 默认值 | 描述         |
| ------ | -------------------------- | ------ | ------------ | 
| action | `number` \| `GlobalAction` | tbd    | 全局按键类型 |     |

# 返回值

`boolean`

是否成功。

---
2023-02-15