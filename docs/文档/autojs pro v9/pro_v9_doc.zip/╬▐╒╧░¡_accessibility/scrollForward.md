# 总览

**scrollForward**(`index?`): `Promise`<`boolean`>

向下或向右滑动

# 参数

| 名称   | 类型   | 默认值 | 描述                          |
| ------ | ------ | ------ | ----------------------------- |
| index? | number | tbd    | 滑动第几个可滑动布局。从0开始 | 


# 返回值

`Promise`<`boolean`>

是否成功的Promise

---
2023-02-15